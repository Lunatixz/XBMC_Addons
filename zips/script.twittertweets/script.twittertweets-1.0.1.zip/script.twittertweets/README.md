Skin Support:

script.twittertweets.default.xml

Control(30100) - Main Group
Control(30101) - Twitter Icon
Control(30102) - Replies Diffuse
Control(30103) - Retweet Diffuse
Control(30104) - Likes Diffuse
Control(30105) - Twitter Username
Control(30106) - Twitter Account
Control(30107) - Post
Control(30108) - Time
Control(30109) - # of Replies
Control(30110) - # of Retweets
Control(30111) - # of Likes